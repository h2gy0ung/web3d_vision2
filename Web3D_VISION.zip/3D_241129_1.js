//웹의 장점: 접근성
//인터렉티브?한 모델링
//js만 사용해서 만들기
//3차원 그래픽에 대한 전반적인 내용
//WebGL = web graphic liabrary
//실습환경  cursur ai 설치
//node.js 검색 및 설치
//blender 검색 및 설치 (오픈소스)
//cursur의 터미널 창에 npm create vite@latest 입력 후 프로젝트 이름 입력 -> vanilla -> javascript 선택
//npm install
//npm i three
//f12 key: function
